void main(void) { output(4+5); }
