gcc -o codegen codegen.c parser.c lex.c tree.c symtable.c
