./lexer $1 $2
