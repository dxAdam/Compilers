gcc -o lexer lexer.c
