./parser $1 $2
